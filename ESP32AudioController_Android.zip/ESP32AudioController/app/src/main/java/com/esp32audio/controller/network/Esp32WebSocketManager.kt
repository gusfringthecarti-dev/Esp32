package com.esp32audio.controller.network

import android.util.Log
import com.esp32audio.controller.model.ConnectionState
import com.esp32audio.controller.model.Esp32Status
import com.google.gson.Gson
import com.google.gson.JsonObject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.util.concurrent.TimeUnit

class Esp32WebSocketManager {

    private val TAG = "ESP32WS"
    private val gson = Gson()
    private var webSocket: WebSocket? = null

    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.SECONDS)   // keep alive
        .writeTimeout(5, TimeUnit.SECONDS)
        .build()

    private val _connectionState = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)
    val connectionState: StateFlow<ConnectionState> = _connectionState

    private val _espStatus = MutableStateFlow(Esp32Status())
    val espStatus: StateFlow<Esp32Status> = _espStatus

    fun connect(ip: String) {
        disconnect()
        _connectionState.value = ConnectionState.Connecting
        val url = "ws://$ip/ws"
        Log.d(TAG, "Connecting to $url")
        val request = Request.Builder().url(url).build()
        webSocket = client.newWebSocket(request, object : WebSocketListener() {

            override fun onOpen(ws: WebSocket, response: Response) {
                Log.d(TAG, "Connected to $ip")
                _connectionState.value = ConnectionState.Connected(ip)
            }

            override fun onMessage(ws: WebSocket, text: String) {
                try {
                    val json = gson.fromJson(text, JsonObject::class.java)
                    when (json.get("type")?.asString) {
                        "status" -> {
                            _espStatus.value = Esp32Status(
                                seqStep   = json.get("seqStep")?.asInt ?: 0,
                                bpm       = json.get("bpm")?.asInt ?: 128,
                                seqPlaying= json.get("seqPlaying")?.asBoolean ?: false,
                                playing   = json.get("playing")?.asBoolean ?: false
                            )
                        }
                        "connected" -> Log.d(TAG, "ESP32 handshake OK")
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Parse error: ${e.message}")
                }
            }

            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                Log.e(TAG, "WS failure: ${t.message}")
                _connectionState.value = ConnectionState.Error(t.message ?: "Connection failed")
            }

            override fun onClosed(ws: WebSocket, code: Int, reason: String) {
                Log.d(TAG, "WS closed: $reason")
                _connectionState.value = ConnectionState.Disconnected
            }
        })
    }

    fun disconnect() {
        webSocket?.close(1000, "User disconnected")
        webSocket = null
        _connectionState.value = ConnectionState.Disconnected
    }

    // ── Send helpers ──────────────────────────────────────────

    fun send(cmd: String, value: Any) {
        val obj = JsonObject().apply {
            addProperty("cmd", cmd)
            when (value) {
                is Boolean -> addProperty("value", value)
                is Number  -> addProperty("value", value)
                else       -> addProperty("value", value.toString())
            }
        }
        sendRaw(obj.toString())
    }

    fun sendSeqGrid(row: Int, col: Int, value: Boolean) {
        val obj = JsonObject().apply {
            addProperty("cmd", "seqGrid")
            addProperty("row", row)
            addProperty("col", col)
            addProperty("value", value)
        }
        sendRaw(obj.toString())
    }

    fun sendChannelVolume(ch: Int, value: Float) {
        val obj = JsonObject().apply {
            addProperty("cmd", "chVol")
            addProperty("ch", ch)
            addProperty("value", value)
        }
        sendRaw(obj.toString())
    }

    fun sendChannelMute(ch: Int, muted: Boolean) {
        val obj = JsonObject().apply {
            addProperty("cmd", "chMute")
            addProperty("ch", ch)
            addProperty("value", muted)
        }
        sendRaw(obj.toString())
    }

    fun sendNoteOn(ch: Int) {
        val obj = JsonObject().apply {
            addProperty("cmd", "noteOn")
            addProperty("ch", ch)
        }
        sendRaw(obj.toString())
    }

    fun sendNoteOff(ch: Int) {
        val obj = JsonObject().apply {
            addProperty("cmd", "noteOff")
            addProperty("ch", ch)
        }
        sendRaw(obj.toString())
    }

    private fun sendRaw(json: String) {
        val ws = webSocket ?: return
        val sent = ws.send(json)
        if (!sent) Log.w(TAG, "Failed to send: $json")
    }

    val isConnected: Boolean
        get() = _connectionState.value is ConnectionState.Connected
}
