package com.esp32audio.controller

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.core.view.WindowCompat
import com.esp32audio.controller.model.ConnectionState
import com.esp32audio.controller.ui.*
import com.esp32audio.controller.ui.theme.*
import com.esp32audio.controller.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent {
            ESP32Theme {
                ESP32App(vm)
            }
        }
    }
}

data class NavTab(val id: String, val label: String, val icon: String)

val NAV_TABS = listOf(
    NavTab("deck",    "DECK",    "▶"),
    NavTab("mixer",   "MIXER",   "⚌"),
    NavTab("eq",      "EQ",      "▦"),
    NavTab("seq",     "SEQ",     "⊞"),
    NavTab("synth",   "SYNTH",   "∿"),
    NavTab("fx",      "FX",      "◈"),
    NavTab("connect", "CONNECT", "⌁"),
)

@Composable
fun ESP32App(vm: MainViewModel) {
    val connState by vm.connectionState.collectAsState()
    val playing   by vm.playing.collectAsState()
    val seqState  by vm.seq.collectAsState()
    val vuLevel   by vm.vuLevel.collectAsState()
    val bpm       by vm.bpm.collectAsState()

    var selectedTab by remember { mutableStateOf("deck") }

    val connected = connState is ConnectionState.Connected

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = BgDark
    ) {
        Column(Modifier.fillMaxSize().systemBarsPadding()) {

            // ── Top status bar ────────────────────────────────
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Panel)
                    .border(BorderStroke(0.5.dp, Border), RoundedCornerShape(0.dp))
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Brand
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        Modifier.size(8.dp).clip(androidx.compose.foundation.shape.CircleShape)
                            .background(Cyan)
                    )
                    Text(
                        "ESP32-AUDIO",
                        color = Cyan,
                        fontSize = 14.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 3.sp
                    )
                    Text("v2.0", color = TextDim, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }

                // Status indicators
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Led(on = playing, color = Green, blink = playing, size = 8.dp, label = "PLAY")
                    Led(on = seqState.playing, color = Orange, blink = seqState.playing, size = 8.dp, label = "SEQ")
                    VuMeter(vuLevel, 2)

                    // Connection pill
                    val statusColor = when (connState) {
                        is ConnectionState.Connected  -> Green
                        is ConnectionState.Connecting -> Yellow
                        is ConnectionState.Error      -> Red
                        else                          -> TextDim
                    }
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(statusColor.copy(alpha = 0.12f))
                            .border(1.dp, statusColor, RoundedCornerShape(12.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            when (connState) {
                                is ConnectionState.Connected    -> "LIVE"
                                is ConnectionState.Connecting   -> "…"
                                is ConnectionState.Error        -> "ERR"
                                is ConnectionState.Disconnected -> "OFF"
                            },
                            color = statusColor,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }
                }

                // BPM clock
                Text(
                    "$bpm",
                    color = Cyan,
                    fontSize = 22.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black
                )
            }

            // ── Screen content ────────────────────────────────
            Box(modifier = Modifier.weight(1f)) {
                AnimatedContent(
                    targetState = selectedTab,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "screen"
                ) { tab ->
                    when (tab) {
                        "deck"    -> DeckScreen(vm)
                        "mixer"   -> MixerScreen(vm)
                        "eq"      -> EqScreen(vm)
                        "seq"     -> SequencerScreen(vm)
                        "synth"   -> SynthScreen(vm)
                        "fx"      -> FxScreen(vm)
                        "connect" -> ConnectScreen(vm)
                        else      -> DeckScreen(vm)
                    }
                }
            }

            // ── Bottom navigation ─────────────────────────────
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Panel)
                    .border(BorderStroke(0.5.dp, Border), RoundedCornerShape(0.dp))
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                NAV_TABS.forEach { tab ->
                    val selected = selectedTab == tab.id
                    // Dot for connect tab when connected
                    val hasDot = tab.id == "connect" && connected

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (selected) Cyan.copy(alpha = 0.1f) else Color.Transparent)
                            .clickable { selectedTab = tab.id }
                            .padding(vertical = 6.dp, horizontal = 2.dp)
                    ) {
                        Box {
                            Text(
                                tab.icon,
                                color = if (selected) Cyan else TextDim,
                                fontSize = 16.sp
                            )
                            if (hasDot) {
                                Box(
                                    Modifier
                                        .size(6.dp)
                                        .align(Alignment.TopEnd)
                                        .clip(androidx.compose.foundation.shape.CircleShape)
                                        .background(Green)
                                )
                            }
                        }
                        Text(
                            tab.label,
                            color = if (selected) Cyan else TextDim,
                            fontSize = 7.sp,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 0.5.sp
                        )
                        if (selected) {
                            Spacer(Modifier.height(2.dp))
                            Box(Modifier.width(20.dp).height(2.dp)
                                .clip(RoundedCornerShape(1.dp)).background(Cyan))
                        }
                    }
                }
            }
        }
    }
}
