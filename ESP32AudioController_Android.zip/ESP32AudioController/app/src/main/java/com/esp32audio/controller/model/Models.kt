package com.esp32audio.controller.model

// ── Sequencer state ───────────────────────────────────────────
data class SequencerState(
    val grid: Array<BooleanArray> = Array(4) { BooleanArray(16) },
    val playing: Boolean = false,
    val currentStep: Int = 0
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is SequencerState) return false
        return playing == other.playing &&
               currentStep == other.currentStep &&
               grid.contentDeepEquals(other.grid)
    }
    override fun hashCode(): Int = grid.contentDeepHashCode()
}

// ── Mixer channel ─────────────────────────────────────────────
data class MixerChannel(
    val label: String,
    val volume: Float = 80f,
    val muted: Boolean = false,
    val solo: Boolean = false,
    val pan: Float = 50f
)

// ── Synth parameters ──────────────────────────────────────────
data class SynthParams(
    val waveform: Int = 0,       // 0=sine 1=saw 2=square 3=tri
    val attack: Float = 20f,
    val decay: Float = 40f,
    val sustain: Float = 70f,
    val release: Float = 30f,
    val cutoff: Float = 80f,
    val resonance: Float = 20f,
    val lfoRate: Float = 50f,
    val lfoDepth: Float = 45f,
    val detune: Float = 50f
)

// ── FX state ──────────────────────────────────────────────────
data class FxState(
    val enabled: Boolean = false,
    val mix: Float = 40f,
    val depth: Float = 50f,
    val rate: Float = 60f
)

val WAVEFORM_NAMES = listOf("SINE", "SAW", "SQUARE", "TRI")

val CHANNEL_LABELS = listOf("KICK", "BASS", "SYNTH", "PAD")

val EQ_BANDS = listOf("32", "64", "125", "250", "500", "1K", "2K", "4K", "8K", "16K")

data class EffectDef(val id: String, val label: String, val cmd: String, val icon: String)

val EFFECT_DEFS = listOf(
    EffectDef("rev",  "REVERB",   "reverb",  "◈"),
    EffectDef("del",  "DELAY",    "delay",   "◎"),
    EffectDef("cho",  "CHORUS",   "chorus",  "⟳"),
    EffectDef("dist", "DISTORT",  "dist",    "⚡"),
    EffectDef("lp",   "LOW PASS", "cutoff",  "▽"),
    EffectDef("hp",   "HI PASS",  "hp",      "△"),
    EffectDef("flng", "FLANGER",  "flanger", "≋"),
    EffectDef("comp", "COMPRES",  "comp",    "⊕"),
)

// ── WebSocket connection states ───────────────────────────────
sealed class ConnectionState {
    object Disconnected : ConnectionState()
    object Connecting : ConnectionState()
    data class Connected(val ip: String) : ConnectionState()
    data class Error(val msg: String) : ConnectionState()
}

// ── Commands sent to ESP32 ────────────────────────────────────
data class Esp32Status(
    val seqStep: Int = 0,
    val bpm: Int = 128,
    val seqPlaying: Boolean = false,
    val playing: Boolean = false
)
