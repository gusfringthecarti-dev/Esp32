package com.esp32audio.controller.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// ── Brand colors ──────────────────────────────────────────────
val Cyan      = Color(0xFF00E5FF)
val CyanDim   = Color(0xFF00B8CC)
val Orange    = Color(0xFFFF6B35)
val Green     = Color(0xFF39FF14)
val Yellow    = Color(0xFFFFCC00)
val Red       = Color(0xFFFF3B5C)

val BgDark    = Color(0xFF080B0F)
val Panel     = Color(0xFF0E1318)
val Card      = Color(0xFF121820)
val Border    = Color(0xFF1A2230)
val Border2   = Color(0xFF243040)
val TextPri   = Color(0xFFC0D0E0)
val TextDim   = Color(0xFF5A7080)
val Dim       = Color(0xFF2A3A4A)

private val DarkColors = darkColorScheme(
    primary          = Cyan,
    onPrimary        = BgDark,
    primaryContainer = Card,
    secondary        = Orange,
    onSecondary      = BgDark,
    tertiary         = Green,
    background       = BgDark,
    onBackground     = TextPri,
    surface          = Panel,
    onSurface        = TextPri,
    surfaceVariant   = Card,
    onSurfaceVariant = TextDim,
    error            = Red,
)

@Composable
fun ESP32Theme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColors,
        content = content
    )
}
