package com.esp32audio.controller.viewmodel

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.esp32audio.controller.model.*
import com.esp32audio.controller.network.Esp32WebSocketManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs: SharedPreferences =
        application.getSharedPreferences("esp32_prefs", Context.MODE_PRIVATE)

    val wsManager = Esp32WebSocketManager()
    val connectionState: StateFlow<ConnectionState> = wsManager.connectionState
    val espStatus: StateFlow<Esp32Status> = wsManager.espStatus

    // ── Saved IP ──────────────────────────────────────────────
    private val _savedIp = MutableStateFlow(prefs.getString("last_ip", "192.168.1.100") ?: "192.168.1.100")
    val savedIp: StateFlow<String> = _savedIp.asStateFlow()

    // ── Transport ─────────────────────────────────────────────
    private val _playing    = MutableStateFlow(false)
    private val _bpm        = MutableStateFlow(128)
    private val _volume     = MutableStateFlow(80f)
    private val _tempo      = MutableStateFlow(100f)
    private val _elapsed    = MutableStateFlow(0f)
    private val _trackIdx   = MutableStateFlow(0)
    private val _loopMode   = MutableStateFlow("none") // none|one|all
    private val _shuffle    = MutableStateFlow(false)
    private val _vuLevel    = MutableStateFlow(0f)

    val playing:   StateFlow<Boolean> = _playing.asStateFlow()
    val bpm:       StateFlow<Int>     = _bpm.asStateFlow()
    val volume:    StateFlow<Float>   = _volume.asStateFlow()
    val tempo:     StateFlow<Float>   = _tempo.asStateFlow()
    val elapsed:   StateFlow<Float>   = _elapsed.asStateFlow()
    val trackIdx:  StateFlow<Int>     = _trackIdx.asStateFlow()
    val loopMode:  StateFlow<String>  = _loopMode.asStateFlow()
    val shuffle:   StateFlow<Boolean> = _shuffle.asStateFlow()
    val vuLevel:   StateFlow<Float>   = _vuLevel.asStateFlow()

    // Fake tracks
    val tracks = listOf(
        Track(1,"Neon Drift","SynthWave_X",128,"Am",214,"Synthwave"),
        Track(2,"Circuit Break","DJ Ohm",140,"Fm",187,"Techno"),
        Track(3,"ESP32 Dreams","MicroCtrl",120,"Cm",243,"Ambient"),
        Track(4,"Pulse Width","PWM Artist",135,"Gm",196,"House"),
        Track(5,"Voltage Drop","ADC Overflow",150,"Dm",178,"Drum&Bass"),
        Track(6,"GPIO Groove","Port_B",126,"Em",231,"Deep House"),
    )

    private var playbackJob: Job? = null
    private var vuJob: Job? = null

    // ── Mixer ─────────────────────────────────────────────────
    private val _channels = MutableStateFlow(
        CHANNEL_LABELS.mapIndexed { i, label ->
            MixerChannel(label, volume = listOf(80f, 75f, 70f, 65f)[i])
        }
    )
    val channels: StateFlow<List<MixerChannel>> = _channels.asStateFlow()

    // ── EQ ────────────────────────────────────────────────────
    private val _eqGains = MutableStateFlow(FloatArray(10) { 0f })
    val eqGains: StateFlow<FloatArray> = _eqGains.asStateFlow()

    // ── Synth ─────────────────────────────────────────────────
    private val _synth = MutableStateFlow(SynthParams())
    val synth: StateFlow<SynthParams> = _synth.asStateFlow()

    // ── Sequencer ─────────────────────────────────────────────
    private val _seq = MutableStateFlow(SequencerState())
    val seq: StateFlow<SequencerState> = _seq.asStateFlow()

    private var seqJob: Job? = null
    private val _localSeqStep = MutableStateFlow(0)
    val localSeqStep: StateFlow<Int> = _localSeqStep.asStateFlow()

    // ── FX ────────────────────────────────────────────────────
    private val _fxMap = MutableStateFlow(
        EFFECT_DEFS.associate { it.id to FxState() }
    )
    val fxMap: StateFlow<Map<String, FxState>> = _fxMap.asStateFlow()

    // ── Tap BPM ───────────────────────────────────────────────
    private val tapTimes = mutableListOf<Long>()

    // ─────────────────────────────────────────────────────────
    //  INIT — watch ESP32 status updates
    // ─────────────────────────────────────────────────────────
    init {
        viewModelScope.launch {
            espStatus.collectLatest { status ->
                // Mirror ESP32 sequencer step
                _seq.value = _seq.value.copy(currentStep = status.seqStep)
            }
        }
    }

    // ─────────────────────────────────────────────────────────
    //  CONNECTION
    // ─────────────────────────────────────────────────────────
    fun connect(ip: String) {
        prefs.edit().putString("last_ip", ip).apply()
        _savedIp.value = ip
        wsManager.connect(ip)
    }

    fun disconnect() = wsManager.disconnect()

    // ─────────────────────────────────────────────────────────
    //  TRANSPORT
    // ─────────────────────────────────────────────────────────
    fun togglePlay() {
        val next = !_playing.value
        _playing.value = next
        wsManager.send("play", next)
        wsManager.send("bpm", _bpm.value)
        if (next) startPlayback() else stopPlayback()
    }

    fun setVolume(v: Float) {
        _volume.value = v
        wsManager.send("volume", v)
    }

    fun setTempo(v: Float) { _tempo.value = v }

    fun setBpm(v: Int) {
        _bpm.value = v
        wsManager.send("bpm", v)
    }

    fun tapBpm() {
        val now = System.currentTimeMillis()
        tapTimes.add(now)
        if (tapTimes.size > 6) tapTimes.removeAt(0)
        if (tapTimes.size >= 2) {
            val gaps = tapTimes.zipWithNext().map { (a, b) -> b - a }
            val avg  = gaps.average()
            val newBpm = (60000.0 / avg).toInt().coerceIn(60, 200)
            setBpm(newBpm)
        }
    }

    fun selectTrack(idx: Int) {
        _trackIdx.value = idx
        _elapsed.value = 0f
        setBpm(tracks[idx].bpm)
    }

    fun nextTrack() { selectTrack((_trackIdx.value + 1) % tracks.size) }
    fun prevTrack() { selectTrack((_trackIdx.value - 1 + tracks.size) % tracks.size) }
    fun seekTo(pos: Float) { _elapsed.value = pos }

    fun cycleLoop() {
        _loopMode.value = when (_loopMode.value) {
            "none" -> "one"
            "one"  -> "all"
            else   -> "none"
        }
    }

    fun toggleShuffle() { _shuffle.value = !_shuffle.value }

    private fun startPlayback() {
        playbackJob?.cancel()
        vuJob?.cancel()
        playbackJob = viewModelScope.launch {
            val track = tracks[_trackIdx.value]
            while (isActive) {
                delay(1000L)
                _elapsed.value += _tempo.value / 100f
                if (_elapsed.value >= track.dur) {
                    when (_loopMode.value) {
                        "one"  -> _elapsed.value = 0f
                        "all"  -> { nextTrack(); _elapsed.value = 0f }
                        else   -> { _playing.value = false; return@launch }
                    }
                }
            }
        }
        vuJob = viewModelScope.launch {
            while (isActive) {
                delay(80)
                _vuLevel.value = (0.45f + 0.55f * Math.random().toFloat()) * (_volume.value / 100f)
            }
        }
    }

    private fun stopPlayback() {
        playbackJob?.cancel()
        vuJob?.cancel()
        _vuLevel.value = 0f
    }

    // ─────────────────────────────────────────────────────────
    //  MIXER
    // ─────────────────────────────────────────────────────────
    fun setChannelVolume(ch: Int, v: Float) {
        _channels.value = _channels.value.toMutableList().also { it[ch] = it[ch].copy(volume = v) }
        wsManager.sendChannelVolume(ch, v)
    }

    fun toggleChannelMute(ch: Int) {
        val muted = !_channels.value[ch].muted
        _channels.value = _channels.value.toMutableList().also { it[ch] = it[ch].copy(muted = muted) }
        wsManager.sendChannelMute(ch, muted)
    }

    fun toggleChannelSolo(ch: Int) {
        _channels.value = _channels.value.toMutableList().also {
            it[ch] = it[ch].copy(solo = !it[ch].solo)
        }
    }

    // ─────────────────────────────────────────────────────────
    //  EQ
    // ─────────────────────────────────────────────────────────
    fun setEqGain(band: Int, gain: Float) {
        val g = _eqGains.value.copyOf().also { it[band] = gain }
        _eqGains.value = g
    }

    fun resetEq() { _eqGains.value = FloatArray(10) { 0f } }

    // ─────────────────────────────────────────────────────────
    //  SYNTH
    // ─────────────────────────────────────────────────────────
    fun setSynthParam(param: String, value: Float) {
        _synth.value = when (param) {
            "attack"    -> _synth.value.copy(attack    = value)
            "decay"     -> _synth.value.copy(decay     = value)
            "sustain"   -> _synth.value.copy(sustain   = value)
            "release"   -> _synth.value.copy(release   = value)
            "cutoff"    -> _synth.value.copy(cutoff    = value)
            "resonance" -> _synth.value.copy(resonance = value)
            "lfoRate"   -> _synth.value.copy(lfoRate   = value)
            "lfoDepth"  -> _synth.value.copy(lfoDepth  = value)
            "detune"    -> _synth.value.copy(detune    = value)
            else        -> _synth.value
        }
        wsManager.send(param, value)
    }

    fun setWaveform(w: Int) {
        _synth.value = _synth.value.copy(waveform = w)
        wsManager.send("waveform", w)
    }

    // ─────────────────────────────────────────────────────────
    //  SEQUENCER
    // ─────────────────────────────────────────────────────────
    fun toggleSeqCell(row: Int, col: Int) {
        val g = _seq.value.grid.map { it.copyOf() }.toTypedArray()
        g[row][col] = !g[row][col]
        _seq.value = _seq.value.copy(grid = g)
        wsManager.sendSeqGrid(row, col, g[row][col])
    }

    fun clearSeq() {
        _seq.value = _seq.value.copy(grid = Array(4) { BooleanArray(16) })
        wsManager.send("seqClear", true)
    }

    fun toggleSeqPlay() {
        val next = !_seq.value.playing
        _seq.value = _seq.value.copy(playing = next)
        wsManager.send("seqPlay", next)
        if (next) startLocalSeq() else { seqJob?.cancel(); _localSeqStep.value = 0 }
    }

    private fun startLocalSeq() {
        seqJob?.cancel()
        seqJob = viewModelScope.launch {
            while (isActive) {
                val ms = (60000.0 / (_bpm.value * 4)).toLong()
                delay(ms)
                _localSeqStep.value = (_localSeqStep.value + 1) % 16
            }
        }
    }

    // ─────────────────────────────────────────────────────────
    //  FX
    // ─────────────────────────────────────────────────────────
    fun toggleFx(id: String) {
        val cur = _fxMap.value[id] ?: FxState()
        val next = cur.copy(enabled = !cur.enabled)
        _fxMap.value = _fxMap.value + (id to next)
        // find command
        val def = EFFECT_DEFS.find { it.id == id }
        if (def != null) wsManager.send(def.cmd, if (next.enabled) next.mix else 0f)
    }

    fun setFxParam(id: String, param: String, value: Float) {
        val cur = _fxMap.value[id] ?: FxState()
        val next = when (param) {
            "mix"   -> cur.copy(mix   = value)
            "depth" -> cur.copy(depth = value)
            "rate"  -> cur.copy(rate  = value)
            else    -> cur
        }
        _fxMap.value = _fxMap.value + (id to next)
        val def = EFFECT_DEFS.find { it.id == id }
        if (def != null && next.enabled) wsManager.send(def.cmd, value)
    }

    override fun onCleared() {
        super.onCleared()
        wsManager.disconnect()
    }
}

data class Track(
    val id: Int,
    val title: String,
    val artist: String,
    val bpm: Int,
    val key: String,
    val dur: Int,
    val genre: String
)
