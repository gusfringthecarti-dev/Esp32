package com.esp32audio.controller.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.esp32audio.controller.model.*
import com.esp32audio.controller.ui.theme.*
import com.esp32audio.controller.viewmodel.MainViewModel
import com.esp32audio.controller.viewmodel.Track
import kotlin.math.*

private val CH_COLORS = listOf(Orange, Cyan, Green, Yellow)

// ═══════════════════════════════════════════════════════
//  DECK SCREEN
// ═══════════════════════════════════════════════════════
@Composable
fun DeckScreen(vm: MainViewModel) {
    val playing   by vm.playing.collectAsState()
    val trackIdx  by vm.trackIdx.collectAsState()
    val elapsed   by vm.elapsed.collectAsState()
    val volume    by vm.volume.collectAsState()
    val tempo     by vm.tempo.collectAsState()
    val bpm       by vm.bpm.collectAsState()
    val loopMode  by vm.loopMode.collectAsState()
    val shuffle   by vm.shuffle.collectAsState()
    val vuLevel   by vm.vuLevel.collectAsState()
    val espStatus by vm.espStatus.collectAsState()

    val track    = vm.tracks[trackIdx]
    val progress = (elapsed / track.dur).coerceIn(0f, 1f)

    // fake waveform data per track
    val waveform = remember(trackIdx) {
        List(64) { i -> 0.2f + 0.7f * abs(sin(i * 0.5f + trackIdx)) }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 12.dp)
    ) {
        item {
            // ── Now playing card ─────────────────────────────
            SectionCard {
                // Track info
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text(
                            track.title,
                            color = TextPri,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.5.sp
                        )
                        Text(track.artist, color = TextDim, fontSize = 13.sp, letterSpacing = 1.sp)
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            TagChip(track.genre)
                            TagChip("KEY: ${track.key}", Orange)
                            TagChip("${track.bpm} BPM", Green)
                        }
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            fmtTime(elapsed),
                            color = Cyan,
                            fontSize = 32.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Text("/ ${fmtTime(track.dur.toFloat())}", color = TextDim, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        Spacer(Modifier.height(4.dp))
                        VuMeter(vuLevel)
                    }
                }

                Spacer(Modifier.height(14.dp))

                // Waveform
                Box(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(Card)
                        .border(1.dp, Border, RoundedCornerShape(6.dp))
                        .padding(horizontal = 4.dp, vertical = 8.dp)
                ) {
                    WaveformDisplay(waveform, progress)
                }

                Spacer(Modifier.height(8.dp))

                // Seek slider
                Slider(
                    value = elapsed,
                    onValueChange = { vm.seekTo(it) },
                    valueRange = 0f..track.dur.toFloat(),
                    colors = SliderDefaults.colors(
                        thumbColor = Cyan,
                        activeTrackColor = Cyan,
                        inactiveTrackColor = Border2
                    )
                )

                Spacer(Modifier.height(8.dp))

                // Transport controls
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TransportButton("⇀", active = shuffle, color = TextDim) { vm.toggleShuffle() }
                    TransportButton("⏮") { vm.prevTrack() }
                    TransportButton("⏪") { vm.seekTo(0f) }

                    // Play/pause - bigger
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(58.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (playing) Cyan else Card)
                            .border(1.dp, if (playing) Cyan else Border2, RoundedCornerShape(8.dp))
                            .clickable { vm.togglePlay() }
                    ) {
                        Text(
                            if (playing) "⏸" else "▶",
                            color = if (playing) BgDark else TextPri,
                            fontSize = 24.sp
                        )
                    }

                    TransportButton("⏩") { vm.seekTo(track.dur.toFloat() - 1) }
                    TransportButton("⏭") { vm.nextTrack() }
                    TransportButton(
                        text = when (loopMode) { "one" -> "↺1"; "all" -> "↺∞"; else -> "↺" },
                        active = loopMode != "none",
                        color = Orange
                    ) { vm.cycleLoop() }
                }
            }
        }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                // BPM card
                SectionCard(title = "BPM CLOCK", modifier = Modifier.weight(1f)) {
                    Box(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp))
                            .background(Card).border(1.dp, Border2, RoundedCornerShape(6.dp))
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            (if (espStatus.bpm > 0) espStatus.bpm else bpm).toString(),
                            color = Cyan, fontSize = 44.sp,
                            fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(
                            onClick = { vm.tapBpm() },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Card),
                            border = BorderStroke(1.dp, Orange)
                        ) {
                            Text("TAP", color = Orange, fontSize = 11.sp, letterSpacing = 2.sp)
                        }
                        IconButton(onClick = { vm.setBpm((bpm - 1).coerceAtLeast(60)) }) {
                            Text("−", color = TextPri, fontSize = 18.sp)
                        }
                        IconButton(onClick = { vm.setBpm((bpm + 1).coerceAtMost(200)) }) {
                            Text("+", color = TextPri, fontSize = 18.sp)
                        }
                    }
                }

                // Levels card
                SectionCard(title = "LEVELS", modifier = Modifier.weight(1f)) {
                    Text("VOLUME  ${volume.toInt()}", color = TextDim, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    Slider(
                        value = volume, onValueChange = { vm.setVolume(it) },
                        valueRange = 0f..100f,
                        colors = SliderDefaults.colors(thumbColor = Cyan, activeTrackColor = Cyan, inactiveTrackColor = Border2)
                    )
                    Spacer(Modifier.height(6.dp))
                    Text("TEMPO  ${tempo.toInt()}%", color = TextDim, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    Slider(
                        value = tempo, onValueChange = { vm.setTempo(it) },
                        valueRange = 50f..200f,
                        colors = SliderDefaults.colors(thumbColor = Orange, activeTrackColor = Orange, inactiveTrackColor = Border2)
                    )
                }
            }
        }

        item {
            SectionCard(title = "TRACK LIBRARY") {
                vm.tracks.forEachIndexed { i, t ->
                    TrackRow(t, i == trackIdx) { vm.selectTrack(i) }
                    if (i < vm.tracks.size - 1) Divider(color = Border, thickness = 0.5.dp)
                }
            }
        }
    }
}

@Composable
private fun TransportButton(text: String, active: Boolean = false, color: Color = TextPri, onClick: () -> Unit) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .size(40.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(if (active) color.copy(alpha = 0.15f) else Card)
            .border(1.dp, if (active) color else Border, RoundedCornerShape(6.dp))
            .clickable(onClick = onClick)
    ) {
        Text(text, color = if (active) color else TextPri, fontSize = 14.sp)
    }
}

@Composable
private fun TrackRow(t: Track, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick)
            .background(if (selected) Cyan.copy(alpha = 0.06f) else Color.Transparent)
            .padding(vertical = 10.dp, horizontal = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(t.title, color = if (selected) Cyan else TextPri, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text(t.artist, color = TextDim, fontSize = 11.sp, letterSpacing = 1.sp)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text("${t.bpm} BPM", color = TextDim, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            Text(fmtTime(t.dur.toFloat()), color = TextDim, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        }
    }
}

// ═══════════════════════════════════════════════════════
//  MIXER SCREEN
// ═══════════════════════════════════════════════════════
@Composable
fun MixerScreen(vm: MainViewModel) {
    val channels by vm.channels.collectAsState()
    val volume   by vm.volume.collectAsState()
    val vuLevel  by vm.vuLevel.collectAsState()

    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        SectionCard(title = "CHANNEL MIXER") {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                channels.forEachIndexed { i, ch ->
                    ChannelStrip(ch, CH_COLORS[i],
                        onVolume = { vm.setChannelVolume(i, it) },
                        onMute   = { vm.toggleChannelMute(i) },
                        onSolo   = { vm.toggleChannelSolo(i) }
                    )
                }
                // Master
                MasterStrip(volume, vuLevel, onVolume = { vm.setVolume(it) })
            }
        }
    }
}

@Composable
private fun ChannelStrip(
    ch: com.esp32audio.controller.model.MixerChannel,
    color: Color,
    onVolume: (Float) -> Unit,
    onMute: () -> Unit,
    onSolo: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(72.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Card)
            .border(1.dp, if (ch.solo) Yellow else if (ch.muted) Red else Border, RoundedCornerShape(8.dp))
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(ch.label, color = color, fontSize = 10.sp, fontFamily = FontFamily.Monospace, letterSpacing = 2.sp)
        VuMeter(if (ch.muted) 0f else ch.volume / 100f, 1)
        Slider(
            value = ch.volume,
            onValueChange = onVolume,
            valueRange = 0f..100f,
            modifier = Modifier.height(120.dp).graphicsLayer { rotationZ = -90f; translationX = -30f; translationY = 30f }.width(120.dp),
            colors = SliderDefaults.colors(thumbColor = color, activeTrackColor = color, inactiveTrackColor = Border2)
        )
        Spacer(Modifier.height(30.dp))
        Text(ch.volume.toInt().toString(), color = color, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
        SmallButton("MUTE", active = ch.muted, activeColor = Red, onClick = onMute)
        SmallButton("SOLO", active = ch.solo,  activeColor = Yellow, onClick = onSolo)
        Knob("PAN", 50f, color = color, size = 46.dp, onValueChange = {})
    }
}

@Composable
private fun MasterStrip(volume: Float, vuLevel: Float, onVolume: (Float) -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(72.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Card)
            .border(2.dp, Cyan, RoundedCornerShape(8.dp))
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("MASTER", color = Cyan, fontSize = 9.sp, fontFamily = FontFamily.Monospace, letterSpacing = 1.sp)
        VuMeter(vuLevel, 2)
        Slider(
            value = volume, onValueChange = onVolume, valueRange = 0f..100f,
            modifier = Modifier.height(120.dp).graphicsLayer { rotationZ = -90f; translationX = -30f; translationY = 30f }.width(120.dp),
            colors = SliderDefaults.colors(thumbColor = Cyan, activeTrackColor = Cyan, inactiveTrackColor = Border2)
        )
        Spacer(Modifier.height(30.dp))
        Text(volume.toInt().toString(), color = Cyan, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
    }
}

// ═══════════════════════════════════════════════════════
//  EQ SCREEN
// ═══════════════════════════════════════════════════════
@Composable
fun EqScreen(vm: MainViewModel) {
    val gains by vm.eqGains.collectAsState()

    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        SectionCard(title = "10-BAND PARAMETRIC EQ") {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                EQ_BANDS.forEachIndexed { i, band ->
                    EqBandColumn(band, gains[i]) { vm.setEqGain(i, it) }
                }
            }

            Spacer(Modifier.height(16.dp))

            // EQ curve
            Canvas(Modifier.fillMaxWidth().height(70.dp).clip(RoundedCornerShape(6.dp)).background(Card)) {
                val w = size.width; val h = size.height
                drawLine(Border2, Offset(0f, h/2), Offset(w, h/2), 0.5f)
                val pts = gains.mapIndexed { i, g ->
                    Offset((i.toFloat() / (gains.size - 1)) * w, h / 2 - g * 2.5f)
                }
                for (i in 0 until pts.size - 1) {
                    drawLine(Cyan, pts[i], pts[i+1], strokeWidth = 2f)
                }
            }

            Spacer(Modifier.height(12.dp))

            Button(
                onClick = { vm.resetEq() },
                colors = ButtonDefaults.buttonColors(containerColor = Card),
                border = BorderStroke(1.dp, Border2),
                modifier = Modifier.align(Alignment.End)
            ) { Text("FLAT", color = TextDim, fontSize = 10.sp, letterSpacing = 2.sp) }
        }
    }
}

@Composable
private fun EqBandColumn(label: String, gain: Float, onChange: (Float) -> Unit) {
    val pct = ((gain + 12f) / 24f).coerceIn(0f, 1f)
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(
            Modifier.width(20.dp).height(110.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(Card).border(1.dp, Border, RoundedCornerShape(3.dp))
        ) {
            Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().fillMaxHeight(pct)
                .background(if (gain > 0) Cyan else if (gain < 0) Red else Dim))
            Box(Modifier.align(Alignment.Center).fillMaxWidth().height(1.dp).background(Border2))
        }
        // drag via slider
        Slider(
            value = gain, onValueChange = onChange, valueRange = -12f..12f,
            modifier = Modifier.width(20.dp).height(0.dp), // hidden; drag on the box instead
            colors = SliderDefaults.colors(thumbColor = Cyan, activeTrackColor = Cyan, inactiveTrackColor = Border)
        )
        Text(label, color = TextDim, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        Text(
            "${if (gain > 0) "+" else ""}${gain.toInt()}",
            color = if (gain != 0f) Cyan else TextDim, fontSize = 7.sp, fontFamily = FontFamily.Monospace
        )
    }
}

// ═══════════════════════════════════════════════════════
//  SEQUENCER SCREEN
// ═══════════════════════════════════════════════════════
@Composable
fun SequencerScreen(vm: MainViewModel) {
    val seq          by vm.seq.collectAsState()
    val localStep    by vm.localSeqStep.collectAsState()
    val bpm          by vm.bpm.collectAsState()
    val conn         by vm.connectionState.collectAsState()
    val espStatus    by vm.espStatus.collectAsState()

    val displayStep  = if (conn is ConnectionState.Connected) espStatus.seqStep else localStep

    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        SectionCard(title = "STEP SEQUENCER") {
            // Header row
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("$bpm BPM", color = Cyan, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmallButton("CLEAR", onClick = { vm.clearSeq() })
                    SmallButton(
                        if (seq.playing) "■ STOP" else "▶ PLAY",
                        active = seq.playing,
                        activeColor = Green
                    ) { vm.toggleSeqPlay() }
                }
            }

            Spacer(Modifier.height(14.dp))

            // Grid
            SingleChildScrollView {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    seq.grid.forEachIndexed { row, steps ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                CHANNEL_LABELS[row],
                                color = CH_COLORS[row],
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.width(40.dp)
                            )
                            steps.forEachIndexed { col, on ->
                                val isCurrent = col == displayStep && seq.playing
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(
                                            when {
                                                on         -> CH_COLORS[row]
                                                isCurrent  -> Border2
                                                else       -> Card
                                            }
                                        )
                                        .border(
                                            1.dp,
                                            if (isCurrent) Color.White else if (on) CH_COLORS[row] else Border,
                                            RoundedCornerShape(4.dp)
                                        )
                                        .clickable { vm.toggleSeqCell(row, col) }
                                )
                            }
                        }
                    }

                    // Step numbers
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Spacer(Modifier.width(44.dp))
                        repeat(16) { i ->
                            Text(
                                "${i + 1}",
                                color = if (i == displayStep && seq.playing) Cyan else TextDim,
                                fontSize = 7.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.width(28.dp),
                            )
                        }
                    }
                }
            }
        }
    }
}

// ═══════════════════════════════════════════════════════
//  SYNTH SCREEN
// ═══════════════════════════════════════════════════════
@Composable
fun SynthScreen(vm: MainViewModel) {
    val synth by vm.synth.collectAsState()

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 12.dp)
    ) {
        item {
            SectionCard(title = "OSCILLATOR") {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("SINE","SAW","SQUARE","TRI").forEachIndexed { i, w ->
                        SmallButton(
                            w, active = synth.waveform == i,
                            modifier = Modifier.weight(1f)
                        ) { vm.setWaveform(i) }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    Knob("DETUNE", synth.detune, color = Cyan) { vm.setSynthParam("detune", it) }
                }
            }
        }
        item {
            SectionCard(title = "ENVELOPE — ADSR") {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Knob("ATTACK",  synth.attack,  color = Orange) { vm.setSynthParam("attack",  it) }
                    Knob("DECAY",   synth.decay,   color = Orange) { vm.setSynthParam("decay",   it) }
                    Knob("SUSTAIN", synth.sustain, color = Orange) { vm.setSynthParam("sustain", it) }
                    Knob("RELEASE", synth.release, color = Orange) { vm.setSynthParam("release", it) }
                }
                Spacer(Modifier.height(12.dp))
                // ADSR visual
                Canvas(Modifier.fillMaxWidth().height(60.dp).clip(RoundedCornerShape(4.dp)).background(Card)) {
                    val w = size.width; val h = size.height
                    val a = synth.attack * 0.4f; val d = synth.decay * 0.2f
                    val s = h - synth.sustain * h * 0.01f * 0.9f; val r = synth.release * 0.3f
                    val pts = listOf(
                        Offset(0f, h), Offset(a, 5f),
                        Offset(a + d, s), Offset(a + d + 80f, s),
                        Offset(a + d + 80f + r, h)
                    )
                    for (i in 0 until pts.size - 1) drawLine(Orange, pts[i], pts[i+1], 2f)
                }
            }
        }
        item {
            SectionCard(title = "FILTER") {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Knob("CUTOFF",    synth.cutoff,    color = Green) { vm.setSynthParam("cutoff",    it) }
                    Knob("RESONANCE", synth.resonance, color = Green) { vm.setSynthParam("resonance", it) }
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("LP","HP","BP","NOTCH").forEachIndexed { i, f ->
                        SmallButton(f, active = i == 0, activeColor = Green, modifier = Modifier.weight(1f)) {}
                    }
                }
            }
        }
        item {
            SectionCard(title = "LFO") {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Knob("RATE",  synth.lfoRate,  color = Yellow) { vm.setSynthParam("lfoRate",  it) }
                    Knob("DEPTH", synth.lfoDepth, color = Yellow) { vm.setSynthParam("lfoDepth", it) }
                }
            }
        }
    }
}

// ═══════════════════════════════════════════════════════
//  FX SCREEN
// ═══════════════════════════════════════════════════════
@Composable
fun FxScreen(vm: MainViewModel) {
    val fxMap by vm.fxMap.collectAsState()

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 12.dp)
    ) {
        item {
            SectionCard(title = "EFFECTS CHAIN") {
                // Effect toggle grid
                val chunked = EFFECT_DEFS.chunked(4)
                chunked.forEach { row ->
                    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { fx ->
                            val state = fxMap[fx.id] ?: FxState()
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (state.enabled) Cyan else Card)
                                    .border(1.dp, if (state.enabled) Cyan else Border2, RoundedCornerShape(6.dp))
                                    .clickable { vm.toggleFx(fx.id) }
                                    .padding(8.dp)
                            ) {
                                Text(fx.icon, fontSize = 18.sp, color = if (state.enabled) BgDark else TextDim)
                                Text(fx.label, fontSize = 8.sp, color = if (state.enabled) BgDark else TextDim,
                                    fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
                            }
                        }
                    }
                }
            }
        }

        // Active effect knobs
        val activeEffects = EFFECT_DEFS.filter { fxMap[it.id]?.enabled == true }
        if (activeEffects.isNotEmpty()) {
            items(activeEffects.size) { i ->
                val fx    = activeEffects[i]
                val state = fxMap[fx.id] ?: FxState()
                SectionCard(title = "${fx.icon} ${fx.label}") {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        Knob("MIX",   state.mix,   color = Cyan)   { vm.setFxParam(fx.id, "mix",   it) }
                        Knob("DEPTH", state.depth, color = Cyan)   { vm.setFxParam(fx.id, "depth", it) }
                        Knob("RATE",  state.rate,  color = Cyan)   { vm.setFxParam(fx.id, "rate",  it) }
                    }
                }
            }
        }
    }
}

// ═══════════════════════════════════════════════════════
//  CONNECT SCREEN
// ═══════════════════════════════════════════════════════
@Composable
fun ConnectScreen(vm: MainViewModel) {
    val connState by vm.connectionState.collectAsState()
    val savedIp   by vm.savedIp.collectAsState()
    var inputIp   by remember { mutableStateOf(savedIp) }

    val statusColor = when (connState) {
        is ConnectionState.Connected    -> Green
        is ConnectionState.Connecting   -> Yellow
        is ConnectionState.Error        -> Red
        is ConnectionState.Disconnected -> TextDim
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 12.dp)
    ) {
        item {
            SectionCard(title = "WiFi CONNECTION") {
                // IP input
                Text("ESP32 IP ADDRESS", color = TextDim, fontSize = 9.sp, fontFamily = FontFamily.Monospace, letterSpacing = 2.sp)
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = inputIp,
                    onValueChange = { inputIp = it },
                    placeholder = { Text("192.168.1.100", color = TextDim) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Cyan,
                        unfocusedBorderColor = Border2,
                        focusedTextColor = Cyan,
                        unfocusedTextColor = TextPri,
                        cursorColor = Cyan
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(12.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { vm.connect(inputIp) },
                        enabled = connState !is ConnectionState.Connected,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Cyan,
                            contentColor = BgDark,
                            disabledContainerColor = Border
                        )
                    ) {
                        Text(
                            when (connState) {
                                is ConnectionState.Connecting -> "CONNECTING…"
                                else -> "CONNECT"
                            },
                            fontWeight = FontWeight.Bold, letterSpacing = 2.sp
                        )
                    }
                    Button(
                        onClick = { vm.disconnect() },
                        enabled = connState is ConnectionState.Connected,
                        colors = ButtonDefaults.buttonColors(containerColor = Red, disabledContainerColor = Border)
                    ) {
                        Text("DISCONNECT", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    }
                }

                Spacer(Modifier.height(14.dp))

                // Status box
                Box(
                    Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(statusColor.copy(alpha = 0.07f))
                        .border(1.dp, statusColor, RoundedCornerShape(6.dp))
                        .padding(14.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Led(on = connState is ConnectionState.Connected ||
                                     connState is ConnectionState.Connecting,
                                color = statusColor, blink = connState is ConnectionState.Connecting, size = 10.dp)
                            Text(
                                when (connState) {
                                    is ConnectionState.Connected    -> "CONNECTED"
                                    is ConnectionState.Connecting   -> "CONNECTING"
                                    is ConnectionState.Error        -> "ERROR"
                                    is ConnectionState.Disconnected -> "DISCONNECTED"
                                },
                                color = statusColor, fontSize = 14.sp,
                                fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold
                            )
                        }
                        if (connState is ConnectionState.Connected) {
                            Spacer(Modifier.height(8.dp))
                            Text("ws://$inputIp/ws", color = TextDim, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            Text("Sample Rate: 44100 Hz", color = TextDim, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }
                        if (connState is ConnectionState.Error) {
                            Spacer(Modifier.height(6.dp))
                            Text((connState as ConnectionState.Error).msg, color = Red, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        item {
            SectionCard(title = "SETUP GUIDE") {
                listOf(
                    Triple("01","Flash Firmware","Open ESP32_Audio_Controller.ino in Arduino IDE. Fill in WiFi credentials. Flash to ESP32-WROOM-32E."),
                    Triple("02","Wire the DAC","PCM5102A: BCK→GPIO25, LCK→GPIO26, DIN→GPIO22. XSMT→3.3V (required). Or set USE_INTERNAL_DAC=1."),
                    Triple("03","Find IP","Open Serial Monitor at 115200 baud. IP prints after WiFi connects."),
                    Triple("04","Connect","Enter IP above, tap CONNECT. Status turns green. All controls go live."),
                ).forEach { (step, title, desc) ->
                    Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(step, color = Cyan.copy(alpha = 0.4f), fontSize = 24.sp,
                            fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black)
                        Column {
                            Text(title, color = TextPri, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(3.dp))
                            Text(desc, color = TextDim, fontSize = 11.sp, lineHeight = 16.sp)
                        }
                    }
                    Divider(color = Border, thickness = 0.5.dp)
                }
            }
        }
    }
}

// ── Helpers ───────────────────────────────────────────────────
private fun fmtTime(seconds: Float): String {
    val s = seconds.toInt()
    return "${(s / 60).toString().padStart(2,'0')}:${(s % 60).toString().padStart(2,'0')}"
}

@Composable
private fun SmallButton(
    text: String,
    active: Boolean = false,
    activeColor: Color = Cyan,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(if (active) activeColor else Card)
            .border(1.dp, if (active) activeColor else Border2, RoundedCornerShape(4.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 7.dp)
    ) {
        Text(
            text,
            color = if (active) BgDark else TextDim,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )
    }
}

@Composable
private fun SingleChildScrollView(content: @Composable () -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState())) {
        content()
    }
}
