package com.esp32audio.controller.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.esp32audio.controller.ui.theme.*
import kotlin.math.*

// ── Knob ──────────────────────────────────────────────────────
@Composable
fun Knob(
    label: String,
    value: Float,
    min: Float = 0f,
    max: Float = 100f,
    color: Color = Cyan,
    size: Dp = 58.dp,
    onValueChange: (Float) -> Unit
) {
    val pct = (value - min) / (max - min)
    val startAngle = -225f  // -135 from 3 o'clock = -225 from right
    val sweepRange = 270f

    var dragStart by remember { mutableStateOf(0f) }
    var startVal  by remember { mutableStateOf(value) }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { offset ->
                        dragStart = offset.y
                        startVal = value
                    },
                    onVerticalDrag = { _, dragAmount ->
                        val delta = -dragAmount / 300f * (max - min)
                        onValueChange((startVal + delta).coerceIn(min, max))
                        startVal += delta
                        startVal = startVal.coerceIn(min, max)
                    }
                )
            }
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val cx = size.toPx() / 2
            val cy = size.toPx() / 2
            val r  = cx - 8.dp.toPx()
            val trackColor = Border2.copy(alpha = 0.8f)

            // Track arc
            drawArc(
                color = trackColor,
                startAngle = startAngle,
                sweepAngle = sweepRange,
                useCenter = false,
                topLeft = Offset(cx - r, cy - r),
                size = androidx.compose.ui.geometry.Size(r * 2, r * 2),
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
            )

            // Fill arc
            if (pct > 0.01f) {
                drawArc(
                    color = color,
                    startAngle = startAngle,
                    sweepAngle = sweepRange * pct,
                    useCenter = false,
                    topLeft = Offset(cx - r, cy - r),
                    size = androidx.compose.ui.geometry.Size(r * 2, r * 2),
                    style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                )
            }

            // Dot indicator
            val angle = (startAngle + sweepRange * pct) * PI.toFloat() / 180f
            val dotR  = r - 5.dp.toPx()
            drawCircle(
                color = color,
                radius = 3.dp.toPx(),
                center = Offset(cx + dotR * cos(angle), cy + dotR * sin(angle))
            )

            // Center circle
            drawCircle(color = Card, radius = cx - 14.dp.toPx())
            drawCircle(color = Border, radius = cx - 14.dp.toPx(), style = Stroke(1.dp.toPx()))
        }

        Spacer(Modifier.height(2.dp))
        Text(
            text = value.toInt().toString(),
            color = color,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = label,
            color = TextDim,
            fontSize = 8.sp,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.sp
        )
    }
}

// ── LED indicator ─────────────────────────────────────────────
@Composable
fun Led(
    on: Boolean,
    color: Color = Green,
    blink: Boolean = false,
    size: Dp = 8.dp,
    label: String? = null
) {
    val alpha by if (on && blink) {
        val inf = rememberInfiniteTransition(label = "led")
        inf.animateFloat(
            initialValue = 1f, targetValue = 0.15f, label = "blink",
            animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse)
        )
    } else {
        remember { mutableStateOf(if (on) 1f else 0.15f) }
    }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(size)
                .clip(CircleShape)
                .background(if (on) color.copy(alpha = alpha) else Border)
                .drawBehind {
                    if (on) drawCircle(color.copy(alpha = 0.3f * alpha), radius = size.toPx())
                }
        )
        if (label != null) {
            Spacer(Modifier.height(2.dp))
            Text(label, color = TextDim, fontSize = 6.sp, fontFamily = FontFamily.Monospace, letterSpacing = 1.sp)
        }
    }
}

// ── VU Meter ──────────────────────────────────────────────────
@Composable
fun VuMeter(level: Float, channels: Int = 2) {
    val bars = 14
    Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        repeat(channels) {
            Column(
                verticalArrangement = Arrangement.spacedBy(1.dp),
                modifier = Modifier.width(6.dp)
            ) {
                (bars downTo 1).forEach { i ->
                    val threshold = i.toFloat() / bars
                    val active = level > threshold
                    val color = when {
                        i > bars * 0.85f -> Red
                        i > bars * 0.6f  -> Yellow
                        else             -> Green
                    }
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(3.dp)
                            .clip(RoundedCornerShape(1.dp))
                            .background(if (active) color else Border)
                    )
                }
            }
        }
    }
}

// ── Waveform display ──────────────────────────────────────────
@Composable
fun WaveformDisplay(
    waveformData: List<Float>,
    progress: Float,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.fillMaxWidth().height(60.dp)) {
        val w = size.width
        val h = size.height
        val n = waveformData.size
        val bw = w / n

        waveformData.forEachIndexed { i, v ->
            val bh = v * h * 0.85f
            val x = i * bw
            val col = if (x / w < progress) Cyan else Dim
            drawRect(
                color = col.copy(alpha = 0.8f),
                topLeft = Offset(x, (h - bh) / 2),
                size = androidx.compose.ui.geometry.Size(bw * 0.7f, bh)
            )
        }

        // Playhead
        drawLine(
            color = Cyan,
            start = Offset(progress * w, 0f),
            end   = Offset(progress * w, h),
            strokeWidth = 1.5f
        )
    }
}

// ── Progress bar ──────────────────────────────────────────────
@Composable
fun ProgressBar(
    value: Float,  // 0-1
    color: Color = Cyan,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .height(6.dp)
            .clip(RoundedCornerShape(3.dp))
            .background(Border)
    ) {
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(value)
                .clip(RoundedCornerShape(3.dp))
                .background(color)
        )
    }
}

// ── Section card ──────────────────────────────────────────────
@Composable
fun SectionCard(
    title: String? = null,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Panel)
            .border(1.dp, Border, RoundedCornerShape(8.dp))
            .padding(16.dp)
    ) {
        if (title != null) {
            Text(
                text = title,
                color = TextDim,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 3.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(14.dp))
        }
        content()
    }
}

// ── Chip / tag ────────────────────────────────────────────────
@Composable
fun TagChip(text: String, color: Color = Cyan) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(3.dp))
            .background(Card)
            .border(1.dp, Border2, RoundedCornerShape(3.dp))
            .padding(horizontal = 8.dp, vertical = 2.dp)
    ) {
        Text(text, color = color, fontSize = 9.sp, fontFamily = FontFamily.Monospace, letterSpacing = 2.sp)
    }
}

// ── Glow button ───────────────────────────────────────────────
@Composable
fun GlowButton(
    text: String,
    active: Boolean,
    color: Color = Cyan,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .clip(RoundedCornerShape(5.dp))
            .background(if (active) color else Card)
            .border(1.dp, if (active) color else Border2, RoundedCornerShape(5.dp))
            .padding(horizontal = 14.dp, vertical = 9.dp)
            .then(Modifier.noRippleClickable(onClick))
    ) {
        Text(
            text = text,
            color = if (active) BgDark else TextPri,
            fontSize = 12.sp,
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )
    }
}

// ── noRipple click helper ─────────────────────────────────────
fun Modifier.noRippleClickable(onClick: () -> Unit): Modifier = this.then(
    Modifier.pointerInput(Unit) {
        awaitPointerEventScope {
            while (true) {
                val event = awaitPointerEvent()
                if (event.changes.all { it.pressed.not() }) onClick()
            }
        }
    }
)
